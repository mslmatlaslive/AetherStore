# App Store Mirror

Bak bana app store tıpatıp aynısıni yapmani istiyorum uygulama hakkında uygulama tiklaninca kaç kere indirilmiş ne var ne yok sonra arama yerine girince olay store deki tüm uygulamalar yazınca çıkmasını istiyorum kopya falan yapma neymiş benzetme aynısı olsun artık hata istemiyorum gerekirse bu bahsettiğim uygulamalar erişmek istiyorsan sunucuya bağlan bir tanesine Android için bir app store yapcam sen yap sonradan ben bazı şeyleri degistircem sorun etme sen yeterli yap aynisi

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/6d08b06f-5370-4f4d-9dfc-124cd328f627).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
