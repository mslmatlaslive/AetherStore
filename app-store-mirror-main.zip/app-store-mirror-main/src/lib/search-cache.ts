import type { AppSummary } from "@/lib/store.functions";

/** Aratılan kelimeler için bellek içi (LRU) önbellek: tekrar aratınca API'ye gitmeden anında gösterilir. */
const MAX_ENTRIES = 100;
const TTL_MS = 10 * 60_000;

type Entry = { at: number; data: AppSummary[] };
const store = new Map<string, Entry>();

export const normalizeQuery = (q: string) => q.toLowerCase().replace(/\s+/g, " ").trim();

export function getCachedSearch(q: string): AppSummary[] | undefined {
  const key = normalizeQuery(q);
  const hit = store.get(key);
  if (!hit) return undefined;
  if (Date.now() - hit.at > TTL_MS) {
    store.delete(key);
    return undefined;
  }
  // LRU: en son kullanılanı sona taşı
  store.delete(key);
  store.set(key, hit);
  return hit.data;
}

export function setCachedSearch(q: string, data: AppSummary[]) {
  const key = normalizeQuery(q);
  store.delete(key);
  store.set(key, { at: Date.now(), data });
  while (store.size > MAX_ENTRIES) {
    const oldest = store.keys().next().value;
    if (oldest === undefined) break;
    store.delete(oldest);
  }
}
