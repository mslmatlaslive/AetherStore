import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

/** Yalnızca @proton.me ve @protonmail.com adreslerine izin verilir. */
export const PROTON_RE = /^[a-z0-9._%+-]+@(proton\.me|protonmail\.com)$/i;
export const PROTON_ERROR = "Yalnızca @proton.me veya @protonmail.com adresleri kabul edilir.";

export type User = { email: string; name: string };

type OpenOpts = { reason?: string; onSuccess?: () => void };

type AuthCtx = {
  user: User | null;
  ready: boolean;
  dialogOpen: boolean;
  reason?: string;
  openAuth: (opts?: OpenOpts) => void;
  closeAuth: () => void;
  /** Giriş yoksa giriş penceresini açar, başarılı girişten sonra fn'i çalıştırır. */
  requireAuth: (fn: () => void, reason?: string) => boolean;
  signIn: (email: string, password: string) => Promise<string | null>;
  signUp: (name: string, email: string, password: string) => Promise<string | null>;
  signOut: () => void;
};

const Ctx = createContext<AuthCtx | null>(null);

const ACC_KEY = "aether:accounts";
const SES_KEY = "aether:session";

type Account = { name: string; salt: string; hash: string };

function readAccounts(): Record<string, Account> {
  try {
    return JSON.parse(localStorage.getItem(ACC_KEY) || "{}");
  } catch {
    return {};
  }
}

const toB64 = (a: Uint8Array) => btoa(String.fromCharCode(...a));
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

async function derive(password: string, salt: Uint8Array) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, [
    "deriveBits",
  ]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: salt as BufferSource, iterations: 100_000, hash: "SHA-256" },
    key,
    256,
  );
  return toB64(new Uint8Array(bits));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [reason, setReason] = useState<string | undefined>();
  const pending = useRef<(() => void) | undefined>(undefined);

  // localStorage yalnızca istemcide okunur (SSR uyumsuzluğunu önlemek için).
  useEffect(() => {
    try {
      const email = localStorage.getItem(SES_KEY);
      const acc = email ? readAccounts()[email] : undefined;
      if (email && acc) setUser({ email, name: acc.name });
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  const openAuth = useCallback((opts?: OpenOpts) => {
    pending.current = opts?.onSuccess;
    setReason(opts?.reason);
    setDialogOpen(true);
  }, []);

  const closeAuth = useCallback(() => {
    pending.current = undefined;
    setDialogOpen(false);
  }, []);

  const finishLogin = useCallback((u: User) => {
    localStorage.setItem(SES_KEY, u.email);
    setUser(u);
    setDialogOpen(false);
    const fn = pending.current;
    pending.current = undefined;
    if (fn) setTimeout(fn, 0);
  }, []);

  const signIn = useCallback(
    async (rawEmail: string, password: string) => {
      const email = rawEmail.trim().toLowerCase();
      if (!PROTON_RE.test(email)) return PROTON_ERROR;
      const acc = readAccounts()[email];
      if (!acc) return "Bu e-posta ile kayıtlı hesap yok. Önce kayıt olun.";
      const hash = await derive(password, fromB64(acc.salt));
      if (hash !== acc.hash) return "Şifre hatalı.";
      finishLogin({ email, name: acc.name });
      return null;
    },
    [finishLogin],
  );

  const signUp = useCallback(
    async (name: string, rawEmail: string, password: string) => {
      const email = rawEmail.trim().toLowerCase();
      if (!PROTON_RE.test(email)) return PROTON_ERROR;
      if (name.trim().length < 2) return "Lütfen adınızı girin.";
      if (password.length < 8) return "Şifre en az 8 karakter olmalı.";
      const accounts = readAccounts();
      if (accounts[email]) return "Bu e-posta zaten kayıtlı. Oturum açın.";
      const salt = crypto.getRandomValues(new Uint8Array(16));
      accounts[email] = { name: name.trim(), salt: toB64(salt), hash: await derive(password, salt) };
      localStorage.setItem(ACC_KEY, JSON.stringify(accounts));
      finishLogin({ email, name: name.trim() });
      return null;
    },
    [finishLogin],
  );

  const signOut = useCallback(() => {
    localStorage.removeItem(SES_KEY);
    setUser(null);
    setDialogOpen(false);
  }, []);

  const requireAuth = useCallback(
    (fn: () => void, why = "Devam etmek için Proton Mail hesabınızla oturum açın.") => {
      if (user) {
        fn();
        return true;
      }
      openAuth({ reason: why, onSuccess: fn });
      return false;
    },
    [user, openAuth],
  );

  const value = useMemo<AuthCtx>(
    () => ({ user, ready, dialogOpen, reason, openAuth, closeAuth, requireAuth, signIn, signUp, signOut }),
    [user, ready, dialogOpen, reason, openAuth, closeAuth, requireAuth, signIn, signUp, signOut],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used inside <AuthProvider>");
  return v;
}
