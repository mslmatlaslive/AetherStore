/**
 * İndirme yöneticisi.
 *  - Android (Capacitor) içinde: yerel "ApkInstaller" eklentisi DownloadManager ile indirir
 *    (sistem bildirim çubuğunda ilerleme gösterir), %100'de Paket Yükleyici'yi otomatik açar.
 *  - Tarayıcıda: /api/apk vekil sunucusu üzerinden akış halinde indirir, ilerlemeyi gösterir,
 *    bitince dosyayı tarayıcıya teslim eder (tarayıcılar kurulum ekranını doğrudan açamaz).
 */
import { useSyncExternalStore } from "react";

export type DlStatus = "downloading" | "installing" | "done" | "error";

export type DlItem = {
  id: string;
  name: string;
  icon: string;
  progress: number; // 0-100
  received: number;
  total: number;
  status: DlStatus;
  note?: string;
};

export type DlTarget = { id: string; name: string; icon: string; apk?: string; size?: number };

// ---------------------------------------------------------------- store
let items: Record<string, DlItem> = {};
let snapshot: DlItem[] = [];
let panelOpen = false;
const listeners = new Set<() => void>();

function emit() {
  snapshot = Object.values(items);
  listeners.forEach((l) => l());
}
const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => listeners.delete(l);
};

function patch(id: string, p: Partial<DlItem>) {
  const cur = items[id];
  if (!cur) return;
  items = { ...items, [id]: { ...cur, ...p } };
  emit();
}

const EMPTY: DlItem[] = [];
export const useDownloads = () => useSyncExternalStore(subscribe, () => snapshot, () => EMPTY);
export const useDownload = (id: string) =>
  useSyncExternalStore(subscribe, () => items[id], () => undefined);

export const usePanelOpen = () =>
  useSyncExternalStore(subscribe, () => panelOpen, () => false);
export function setPanelOpen(v: boolean) {
  panelOpen = v;
  listeners.forEach((l) => l());
}

export const isActive = (d?: DlItem) => d?.status === "downloading" || d?.status === "installing";

// ---------------------------------------------------------------- native bridge
type NativePlugin = {
  canInstall(): Promise<{ granted: boolean }>;
  openInstallSettings(): Promise<void>;
  download(o: { url: string; fileName: string; title: string }): Promise<{ downloadId: number }>;
  addListener(ev: string, cb: (e: any) => void): Promise<unknown> | unknown; // eslint-disable-line @typescript-eslint/no-explicit-any
};

let nativePlugin: NativePlugin | null | undefined;
function getNative(): NativePlugin | null {
  if (typeof window === "undefined") return null;
  if (nativePlugin !== undefined) return nativePlugin;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cap = (window as any).Capacitor;
  const isNative = !!cap?.isNativePlatform?.() && cap.getPlatform?.() === "android";
  nativePlugin = isNative ? (cap.registerPlugin?.("ApkInstaller") ?? cap.Plugins?.ApkInstaller ?? null) : null;
  if (nativePlugin) wireNativeEvents(nativePlugin);
  return nativePlugin;
}
export const isNativeAndroid = () => !!getNative();

const nativeIdToApp = new Map<number, string>();

function wireNativeEvents(p: NativePlugin) {
  p.addListener("downloadProgress", (e: { downloadId: number; progress: number; received: number; total: number }) => {
    const id = nativeIdToApp.get(e.downloadId);
    if (id) patch(id, { progress: Math.max(1, Math.min(100, e.progress)), received: e.received, total: e.total });
  });
  p.addListener("installLaunched", (e: { downloadId: number }) => {
    const id = nativeIdToApp.get(e.downloadId);
    if (id) patch(id, { progress: 100, status: "done", note: "Kurulum ekranı açıldı" });
  });
  p.addListener("downloadComplete", (e: { downloadId: number }) => {
    const id = nativeIdToApp.get(e.downloadId);
    if (id) patch(id, { progress: 100, status: "installing", note: "Paket yükleyici açılıyor…" });
  });
  p.addListener("downloadFailed", (e: { downloadId: number; reason?: string }) => {
    const id = nativeIdToApp.get(e.downloadId);
    if (id) patch(id, { status: "error", note: e.reason || "İndirme başarısız" });
  });
}

// ---------------------------------------------------------------- install permission (REQUEST_INSTALL_PACKAGES)
const PERM_KEY = "aether:install-permission";

/** Bir defaya mahsus izin verilmiş mi? */
export async function checkInstallPermission(): Promise<boolean> {
  const n = getNative();
  if (n) {
    try {
      return (await n.canInstall()).granted;
    } catch {
      return false;
    }
  }
  try {
    return localStorage.getItem(PERM_KEY) === "granted";
  } catch {
    return false;
  }
}

function waitForResume(timeoutMs = 120_000) {
  return new Promise<void>((resolve) => {
    const done = () => {
      document.removeEventListener("visibilitychange", onVis);
      clearTimeout(t);
      resolve();
    };
    const onVis = () => document.visibilityState === "visible" && done();
    const t = setTimeout(done, timeoutMs);
    document.addEventListener("visibilitychange", onVis);
  });
}

/** İzni ister. Android'de sistem ayarlarını açar, kullanıcı dönünce durumu yeniden okur. */
export async function requestInstallPermission(): Promise<boolean> {
  const n = getNative();
  if (n) {
    await n.openInstallSettings();
    await waitForResume();
    return (await n.canInstall()).granted;
  }
  try {
    localStorage.setItem(PERM_KEY, "granted");
  } catch {
    /* ignore */
  }
  return true;
}

// ---------------------------------------------------------------- start
const safeName = (s: string) => s.replace(/[^\w.-]+/g, "_");

export async function startDownload(app: DlTarget) {
  if (!app.apk || isActive(items[app.id])) return;
  items = {
    ...items,
    [app.id]: {
      id: app.id,
      name: app.name,
      icon: app.icon,
      progress: 1,
      received: 0,
      total: app.size ?? 0,
      status: "downloading",
    },
  };
  emit();
  setPanelOpen(false);

  const native = getNative();
  try {
    if (native) {
      const { downloadId } = await native.download({
        url: app.apk,
        fileName: `${safeName(app.id)}.apk`,
        title: app.name,
      });
      nativeIdToApp.set(downloadId, app.id);
    } else {
      await webDownload(app);
    }
  } catch (e) {
    patch(app.id, { status: "error", note: e instanceof Error ? e.message : "İndirme başarısız" });
  }
}

async function webDownload(app: DlTarget) {
  const res = await fetch(`/api/apk?url=${encodeURIComponent(app.apk!)}`);
  if (!res.ok || !res.body) throw new Error(`İndirme başlatılamadı (${res.status})`);
  const total = Number(res.headers.get("content-length")) || app.size || 0;
  const reader = res.body.getReader();
  const chunks: Uint8Array[] = [];
  let received = 0;
  let lastPct = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    received += value.length;
    const pct = total ? Math.max(1, Math.min(99, Math.floor((received / total) * 100))) : lastPct;
    if (pct !== lastPct) {
      lastPct = pct;
      patch(app.id, { progress: pct, received, total });
    }
  }
  patch(app.id, { progress: 100, received, total: total || received, status: "installing", note: "Dosya hazırlanıyor…" });

  const blob = new Blob(chunks as BlobPart[], { type: "application/vnd.android.package-archive" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${safeName(app.id)}.apk`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
  patch(app.id, {
    status: "done",
    note: "İndirildi — kurmak için tarayıcı indirme bildirimine dokunun",
  });
}

export function clearFinished() {
  items = Object.fromEntries(Object.entries(items).filter(([, d]) => isActive(d)));
  emit();
}
