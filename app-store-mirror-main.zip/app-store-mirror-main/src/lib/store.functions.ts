import { createServerFn } from "@tanstack/react-start";
import { setResponseHeader } from "@tanstack/react-start/server";
import { z } from "zod";

const API = "https://ws75.aptoide.com/api/7";

export type AppSummary = {
  id: string; // package name
  name: string;
  developer: string;
  icon: string;
  genre: string;
  rating?: number;
  ratingCount?: number;
  downloads?: number;
  price?: string;
  apk?: string;
  size?: number;
};

export type AppDetail = AppSummary & {
  description: string;
  releaseNotes?: string;
  version: string;
  updated: string;
  released: string;
  size: number;
  age: string;
  languages: string[];
  minOs: string;
  screenshots: string[];
  url: string;
  graphic?: string;
  permissions: string[];
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapApp(r: any): AppSummary {
  const s = r.stats ?? {};
  const rating = s.prating?.total ? s.prating : s.rating;
  const rawGenre: string[] = r.media?.keywords ?? [];
  const genre = rawGenre.find(
    (k) => k.length > 2 && !/market|apps|store|aptoide/i.test(k),
  );
  return {
    id: r.package,
    name: r.name,
    developer: r.developer?.name ?? r.store?.name ?? "",
    icon: r.icon,
    genre: genre ? genre.charAt(0).toUpperCase() + genre.slice(1) : "Uygulama",
    rating: rating?.avg,
    ratingCount: rating?.total,
    downloads: s.pdownloads || s.downloads,
    price: "Ücretsiz",
    apk: r.file?.path,
    size: r.size,
  };
}

async function getJson(url: string) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  return res.json();
}

function cache(sec: number) {
  try {
    setResponseHeader("cache-control", `public, max-age=${sec}`);
  } catch {
    /* ignore */
  }
}

export const getCharts = createServerFn({ method: "GET" })
  .inputValidator((d) =>
    z.object({ kind: z.enum(["top-free", "top-paid"]), limit: z.number().max(100), offset: z.number().min(0).default(0) }).parse(d),
  )
  .handler(async ({ data }) => {
    cache(600);
    const sort = data.kind === "top-free" ? "pdownloads" : "latest";
    const json = await getJson(`${API}/apps/get?limit=${data.limit}&offset=${data.offset}&sort=${sort}`);
    const apps = (json.datalist?.list ?? []).map(mapApp) as AppSummary[];
    // Liste uç noktası APK bağlantısını vermez; eksikleri detay sorgusundan tamamla.
    await Promise.all(
      apps.map(async (a) => {
        if (a.apk) return;
        try {
          const meta = await getJson(`${API}/app/getMeta?package_name=${a.id}`);
          a.apk = meta.data?.file?.path;
        } catch {
          /* ignore */
        }
      }),
    );
    return apps;
  });

/** Popüler oyun/uygulama takma adları -> Aptoide paket adları (arama fallback'i). */
export const POPULAR_PACKAGES: { keys: string[]; packages: string[] }[] = [
  { keys: ["free fire", "freefire", "garena", "ff"], packages: ["com.dts.freefireth", "com.dts.freefiremax"] },
  { keys: ["pubg", "pubg mobile", "pubgm"], packages: ["com.tencent.ig", "com.pubg.krmobile"] },
  { keys: ["roblox"], packages: ["com.roblox.client"] },
  { keys: ["minecraft"], packages: ["com.mojang.minecraftpe"] },
  { keys: ["brawl stars", "brawl"], packages: ["com.supercell.brawlstars"] },
  { keys: ["clash of clans", "coc"], packages: ["com.supercell.clashofclans"] },
  { keys: ["clash royale"], packages: ["com.supercell.clashroyale"] },
  { keys: ["call of duty", "cod mobile", "codm"], packages: ["com.activision.callofduty.shooter"] },
  { keys: ["mobile legends", "mlbb"], packages: ["com.mobile.legends"] },
  { keys: ["genshin", "genshin impact"], packages: ["com.miHoYo.GenshinImpact"] },
  { keys: ["among us"], packages: ["com.innersloth.spacemafia"] },
  { keys: ["subway surfers", "subway"], packages: ["com.kiloo.subwaysurf"] },
  { keys: ["candy crush"], packages: ["com.king.candycrushsaga"] },
  { keys: ["efootball", "pes"], packages: ["jp.konami.pesam"] },
];

/** Oyunlar / Uygulamalar sekmelerinde sabit gösterilen öne çıkan içerikler. */
export const PINNED_APPS = [
  { id: "com.dts.freefireth", name: "Garena Free Fire", developer: "Garena International I", genre: "Aksiyon" },
  { id: "com.tencent.ig", name: "PUBG MOBILE", developer: "Level Infinite", genre: "Aksiyon" },
  { id: "com.roblox.client", name: "Roblox", developer: "Roblox Corporation", genre: "Macera" },
] as const;

function normalizeTerm(t: string) {
  return t.toLowerCase().replace(/\s+/g, " ").trim();
}

function packagesForTerm(term: string): string[] {
  const n = normalizeTerm(term);
  const compact = n.replace(/\s/g, "");
  const out = new Set<string>();
  // Kullanıcı doğrudan paket adı yazdıysa (ör. com.dts.freefireth)
  if (/^[a-z][\w]*(\.[\w]+){2,}$/i.test(n)) out.add(n);
  for (const e of POPULAR_PACKAGES) {
    if (e.keys.some((k) => k === n || k.replace(/\s/g, "") === compact || (n.length >= 3 && k.startsWith(n)))) {
      e.packages.forEach((p) => out.add(p));
    }
  }
  return [...out];
}

/** Paket adına göre tek bir uygulamayı (APK bağlantısıyla) getirir; bulunamazsa null. */
async function fetchByPackage(pkg: string): Promise<AppSummary | null> {
  try {
    const res = await fetch(`${API}/app/getMeta?package_name=${encodeURIComponent(pkg)}`);
    if (!res.ok) return null;
    const json = await res.json();
    return json.data?.package ? mapApp(json.data) : null;
  } catch {
    return null;
  }
}

/** Aptoide arama: filtreler genişletildi (trusted=false), sorgu varyantları ve paket fallback'i birleştirilir. */
async function aptoideSearch(query: string, limit: number, offset: number): Promise<AppSummary[]> {
  const url = `${API}/apps/search?query=${encodeURIComponent(query)}&limit=${limit}&offset=${offset}&trusted=false`;
  try {
    const json = await getJson(url);
    return (json.datalist?.list ?? []).map(mapApp) as AppSummary[];
  } catch {
    return [];
  }
}

export const searchApps = createServerFn({ method: "GET" })
  .inputValidator((d) => z.object({ term: z.string().min(1).max(100), offset: z.number().min(0).default(0) }).parse(d))
  .handler(async ({ data }) => {
    cache(300);
    const term = data.term.trim();
    const compact = term.replace(/\s+/g, "");
    const queries = [term];
    // "free fire" -> "freefire" gibi boşluksuz varyant da dene
    if (compact !== term && compact.length >= 3) queries.push(compact);

    const pkgs = data.offset === 0 ? packagesForTerm(term) : [];
    const pkgPromise: Promise<(AppSummary | null)[]> = Promise.all(pkgs.map((p) => fetchByPackage(p)));
    const listPromise: Promise<AppSummary[][]> = Promise.all(queries.map((q) => aptoideSearch(q, 40, data.offset)));
    const [pkgHits, lists] = await Promise.all([pkgPromise, listPromise]);

    // Paket eşleşmeleri en üstte, ardından normal sonuçlar; tekrarlar elenir.
    const seen = new Set<string>();
    const merged: AppSummary[] = [];
    const candidates: (AppSummary | null)[] = [...pkgHits, ...lists.flat()];
    for (const a of candidates) {
      if (!a?.id || seen.has(a.id)) continue;
      seen.add(a.id);
      merged.push(a);
    }
    // Liste uç noktası bazen APK bağlantısı vermez; eksikleri (ilk 15) detay sorgusundan tamamla.
    await Promise.all(
      merged.slice(0, 15).map(async (a) => {
        if (a.apk) return;
        const meta = await fetchByPackage(a.id);
        if (meta?.apk) a.apk = meta.apk;
      }),
    );
    return merged;
  });

/** Sabit öne çıkan kartlar (Free Fire, PUBG Mobile, Roblox). Ağ hatasında bile kart görünür. */
export const getPinnedApps = createServerFn({ method: "GET" }).handler(async () => {
  cache(600);
  const results = await Promise.all(PINNED_APPS.map((p) => fetchByPackage(p.id)));
  return PINNED_APPS.map((p, i): AppSummary => {
    const r = results[i];
    return (
      r ?? {
        id: p.id,
        name: p.name,
        developer: p.developer,
        genre: p.genre,
        icon: `data:image/svg+xml;utf8,${encodeURIComponent(
          `<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120"><rect width="120" height="120" fill="#4f46e5"/><text x="60" y="76" font-size="52" font-family="sans-serif" font-weight="700" fill="#fff" text-anchor="middle">${p.name.charAt(0)}</text></svg>`,
        )}`,
        price: "Ücretsiz",
      }
    );
  }).map((a, i) => ({ ...a, name: a.name || PINNED_APPS[i].name }));
});

export const getApp = createServerFn({ method: "GET" })
  .inputValidator((d) => z.object({ id: z.string().regex(/^[\w.]+$/) }).parse(d))
  .handler(async ({ data }) => {
    cache(600);
    const json = await getJson(`${API}/app/getMeta?package_name=${data.id}`);
    const r = json.data;
    if (!r) return null;
    const detail: AppDetail = {
      ...mapApp(r),
      description: r.media?.description ?? "",
      releaseNotes: r.media?.news,
      version: r.file?.vername ?? "",
      updated: r.updated ?? r.modified,
      released: r.added,
      size: Number(r.size ?? 0),
      age: r.age?.pegi ?? r.age?.title ?? "3+",
      languages: [],
      minOs: r.file?.hardware?.sdk ? `SDK ${r.file.hardware.sdk}` : "-",
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      screenshots: (r.media?.screenshots ?? []).map((s: any) => s.url),
      url: r.file?.path ?? "",
      graphic: r.graphic,
      permissions: r.file?.used_permissions ?? [],
    };
    return detail;
  });

export const GAME_CATEGORIES = [
  { key: "action", label: "Aksiyon", term: "action game", emoji: "⚔️" },
  { key: "puzzle", label: "Bulmaca", term: "puzzle game", emoji: "🧩" },
  { key: "racing", label: "Yarış", term: "racing game", emoji: "🏎️" },
  { key: "strategy", label: "Strateji", term: "strategy game", emoji: "♟️" },
  { key: "sports", label: "Spor", term: "sports game", emoji: "⚽" },
  { key: "adventure", label: "Macera", term: "adventure game", emoji: "🗺️" },
  { key: "simulation", label: "Simülasyon", term: "simulator game", emoji: "🚜" },
  { key: "rpg", label: "Rol Yapma", term: "rpg game", emoji: "🛡️" },
] as const;

/** Oyunlar sekmesi: öne çıkanlar, popülerler ve kategori listeleri. */
export const getGames = createServerFn({ method: "GET" })
  .inputValidator((d) =>
    z
      .object({
        section: z.enum(["featured", "popular", "new", "category"]),
        category: z.string().max(20).optional(),
        limit: z.number().min(1).max(40).default(12),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    cache(600);
    const term =
      data.section === "featured"
        ? "game"
        : data.section === "popular"
          ? "multiplayer game"
          : data.section === "new"
            ? "new game"
            : (GAME_CATEGORIES.find((c) => c.key === data.category)?.term ?? "game");
    const apps = await aptoideSearch(term, data.limit, 0);
    return apps.map((a) => ({ ...a, genre: a.genre === "Uygulama" ? "Oyun" : a.genre }));
  });
