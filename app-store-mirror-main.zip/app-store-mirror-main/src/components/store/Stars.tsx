import { Star } from "lucide-react";

export function Stars({ value, size = 12 }: { value: number; size?: number }) {
  return (
    <span className="inline-flex gap-px text-muted-foreground">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          style={{ width: size, height: size }}
          className={value >= i - 0.5 ? "fill-current" : ""}
        />
      ))}
    </span>
  );
}
