import { User } from "lucide-react";
import { useAuth } from "@/lib/auth";

/** Sağ üst köşedeki yuvarlak profil avatarı (App Store tarzı). */
export function ProfileButton() {
  const { user, openAuth } = useAuth();
  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-[45] pt-[calc(env(safe-area-inset-top)+10px)]">
      <div className="mx-auto flex max-w-2xl justify-end px-5">
        <button
          onClick={() => openAuth()}
          aria-label={user ? "Hesap" : "Oturum aç"}
          className="pointer-events-auto flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-primary via-chart-2 to-chart-4 text-[15px] font-semibold text-white shadow-md ring-1 ring-border transition-transform active:scale-95"
        >
          {user ? user.name.charAt(0).toUpperCase() : <User className="h-5 w-5" />}
        </button>
      </div>
    </div>
  );
}
