import { isActive, useDownload } from "@/lib/downloads";

/** Uygulama kartının altında gösterilen ince ilerleme çubuğu (%1 → %100). */
export function DownloadBar({ id, className = "" }: { id: string; className?: string }) {
  const d = useDownload(id);
  if (!d || d.status === "error") return null;
  if (d.status === "done") return null;
  return (
    <div className={`flex items-center gap-2 ${className}`} role="progressbar" aria-valuenow={d.progress} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-black/15 dark:bg-white/20">
        <div className="h-full rounded-full bg-primary transition-[width] duration-200" style={{ width: `${d.progress}%` }} />
      </div>
      <span className="w-9 text-right text-[11px] font-semibold tabular-nums">%{d.progress}</span>
    </div>
  );
}

/** Dairesel ilerleme halkası (düğmenin yerine geçer). */
export function ProgressRing({ value, size = 32 }: { value: number; size?: number }) {
  const r = (size - 4) / 2;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={3} className="stroke-current opacity-20" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        strokeWidth={3}
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - value / 100)}
        className="stroke-current transition-[stroke-dashoffset] duration-200"
      />
    </svg>
  );
}

export { isActive };
