import { useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPinnedApps, type AppSummary } from "@/lib/store.functions";
import { AppIcon, GetButton, formatCount } from "@/components/store/AppRow";
import { DownloadBar } from "@/components/store/DownloadProgress";
import { useAuth } from "@/lib/auth";

const gradients = [
  "from-orange-500 via-rose-500 to-fuchsia-600",
  "from-emerald-500 via-teal-600 to-cyan-600",
  "from-sky-500 via-blue-600 to-violet-700",
];

export function usePinnedApps() {
  const fn = useServerFn(getPinnedApps);
  return useQuery({ queryKey: ["pinned-apps"], queryFn: () => fn(), staleTime: 600_000 });
}

/** Garena Free Fire, PUBG Mobile, Roblox: sabit öne çıkan kartlar (yatay kaydırma). */
export function PinnedCards({ apps }: { apps?: AppSummary[] }) {
  const router = useRouter();
  const { user, openAuth } = useAuth();
  const open = (id: string) => {
    if (!user) {
      openAuth({ reason: "Sayfaları görmek için Proton Mail hesabınızla oturum açın." });
      return;
    }
    void router.navigate({ to: "/app/$id", params: { id } });
  };
  if (!apps?.length) return null;
  return (
    <div className="no-scrollbar flex snap-x snap-mandatory gap-4 overflow-x-auto px-5">
      {apps.map((g, i) => (
        <div
          key={g.id}
          role="link"
          tabIndex={0}
          onClick={() => open(g.id)}
          onKeyDown={(e) => e.key === "Enter" && open(g.id)}
          className="relative aspect-[4/5] w-[82%] max-w-[340px] shrink-0 cursor-pointer snap-center overflow-hidden rounded-3xl shadow-[var(--shadow-card)] transition-transform active:scale-[0.98]"
        >
          <img src={g.icon} alt="" className="absolute inset-0 h-full w-full scale-[3.5] object-cover blur-2xl" />
          <div className={`absolute inset-0 bg-gradient-to-br ${gradients[i % gradients.length]} opacity-60 mix-blend-multiply`} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/30" />
          <span className="absolute left-0 top-0 rounded-br-2xl bg-black/35 px-4 py-2 text-[12px] font-bold uppercase tracking-wide text-white backdrop-blur">
            Popüler
          </span>
          <div className="absolute inset-x-0 top-[16%] flex justify-center">
            <AppIcon src={g.icon} size={120} />
          </div>
          <div className="absolute inset-x-0 bottom-0 p-4 text-white">
            <p className="text-[11px] font-bold uppercase tracking-wide text-white/80">{g.genre}</p>
            <p className="truncate text-[24px] font-bold leading-tight">{g.name}</p>
            <p className="truncate text-[14px] text-white/80">{g.developer}</p>
            <div className="mt-3 flex items-center justify-between gap-3 rounded-2xl bg-black/30 p-3 backdrop-blur">
              <p className="min-w-0 truncate text-[12px] text-white/80">{formatCount(g.downloads ?? 0)} indirme</p>
              <GetButton app={g} label="indir" overlay />
            </div>
            <DownloadBar id={g.id} className="mt-2 text-white" />
          </div>
        </div>
      ))}
    </div>
  );
}
