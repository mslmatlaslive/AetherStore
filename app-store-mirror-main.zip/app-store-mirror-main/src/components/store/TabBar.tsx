import { Link } from "@tanstack/react-router";
import { Gamepad2, LayoutGrid, Search, Sparkles } from "lucide-react";

const tabs = [
  { to: "/", label: "Bugün", icon: Sparkles },
  { to: "/games", label: "Oyunlar", icon: Gamepad2 },
  { to: "/charts", label: "Uygulamalar", icon: LayoutGrid },
] as const;

export function TabBar() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-50 px-5 pb-[calc(env(safe-area-inset-bottom)+10px)]">
      <div className="mx-auto flex max-w-lg items-center gap-2.5">
        {/* Ince ve zarif ana çubuk */}
        <div className="flex flex-1 justify-around rounded-full border border-border bg-background/75 px-1 py-1 shadow-[var(--shadow-card)] backdrop-blur-2xl">
          {tabs.map((t) => (
            <Link
              key={t.to}
              to={t.to}
              activeOptions={{ exact: t.to === "/" }}
              className="flex flex-1 flex-col items-center gap-px rounded-full py-1 text-[9px] font-semibold text-muted-foreground"
              activeProps={{ className: "text-primary" }}
            >
              <t.icon className="h-[19px] w-[19px]" strokeWidth={2.2} />
              {t.label}
            </Link>
          ))}
        </div>

        {/* Ayrı, yüzen arama düğmesi */}
        <Link
          to="/search"
          aria-label="Ara"
          className="flex h-[46px] w-[46px] shrink-0 items-center justify-center rounded-full border border-border bg-background/75 text-muted-foreground shadow-[var(--shadow-card)] backdrop-blur-2xl transition-transform active:scale-95 data-[status=active]:border-primary data-[status=active]:bg-primary data-[status=active]:text-primary-foreground"
        >
          <Search className="h-[21px] w-[21px]" strokeWidth={2.4} />
        </Link>
      </div>
    </nav>
  );
}
