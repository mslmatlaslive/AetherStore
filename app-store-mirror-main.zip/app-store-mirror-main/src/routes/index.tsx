import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getCharts } from "@/lib/store.functions";
import { AppIcon, AppRow, GetButton, formatCount } from "@/components/store/AppRow";
import { DownloadBar } from "@/components/store/DownloadProgress";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bugün — AetherOS" },
      { name: "description", content: "Günün öne çıkan uygulamaları ve en popüler listeler." },
      { property: "og:title", content: "Bugün — AetherOS" },
      { property: "og:description", content: "Günün öne çıkan uygulamaları ve en popüler listeler." },
    ],
  }),
  component: Today,
});

const featuredLabels = ["ŞU ANDA GERÇEKLEŞİYOR", "GÜNÜN UYGULAMASI", "ÖNE ÇIKAN"];

function Today() {
  const fn = useServerFn(getCharts);
  const { data, isLoading, error } = useQuery({
    queryKey: ["charts", "top-free", 30],
    queryFn: () => fn({ data: { kind: "top-free", limit: 30, offset: 0 } }),
    staleTime: 600_000,
  });
  const router = useRouter();
  const { user, openAuth } = useAuth();
  const openApp = (id: string) => {
    if (!user) {
      openAuth({ reason: "Uygulama sayfalarını görmek için Proton Mail hesabınızla oturum açın." });
      return;
    }
    void router.navigate({ to: "/app/$id", params: { id } });
  };
  const date = new Date().toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" });
  const featured = data?.slice(0, 3) ?? [];

  return (
    <div className="px-5 pt-5">
      <header className="flex items-start justify-between">
        <div>
          <p className="text-[13px] font-semibold uppercase tracking-wide text-muted-foreground">{date}</p>
          <h1 className="text-[36px] font-extrabold leading-tight tracking-tight">AetherOS</h1>
        </div>
        {/* Profil avatarı artık sağ üstte sabit (ProfileButton) */}
        <div className="h-11 w-11" aria-hidden />
      </header>

      {isLoading && <p className="mt-10 text-center text-muted-foreground">Yükleniyor…</p>}
      {error && <p className="mt-10 text-center text-destructive">Veriler alınamadı.</p>}

      <div className="mt-4 space-y-6">
        {featured.map((app, i) => (
          <div
            key={app.id}
            role="link"
            tabIndex={0}
            onClick={() => openApp(app.id)}
            onKeyDown={(e) => e.key === "Enter" && openApp(app.id)}
            className="relative block cursor-pointer aspect-[5/4] overflow-hidden rounded-3xl shadow-[var(--shadow-card)] transition-transform active:scale-[0.97]"
          >
            <img src={app.icon} alt="" className="absolute inset-0 h-full w-full scale-[3.5] object-cover blur-2xl" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-black/40" />
            <span className="absolute left-0 top-0 rounded-br-2xl bg-black/35 px-4 py-2 text-[12px] font-bold uppercase tracking-wide text-white backdrop-blur">
              {featuredLabels[i]}
            </span>
            <div className="absolute inset-x-0 top-[12%] flex justify-center">
              <AppIcon src={app.icon} size={96} />
            </div>
            <div className="absolute inset-x-0 bottom-0 p-5 text-white">
              <p className="text-[11px] font-bold uppercase tracking-wide text-white/80">{app.genre}</p>
              <p className="mt-0.5 text-[26px] font-bold leading-tight">{app.name}</p>
              <p className="text-[15px] text-white/80">{app.developer}</p>
              <div className="mt-3 flex items-center justify-between gap-3 rounded-2xl bg-black/30 p-3 backdrop-blur">
                <div className="flex min-w-0 items-center gap-3">
                  <AppIcon src={app.icon} size={44} />
                  <div className="min-w-0">
                    <p className="truncate text-[15px] font-semibold">{app.name}</p>
                    <p className="truncate text-[12px] text-white/70">
                      {formatCount(app.downloads ?? 0)} indirme
                    </p>
                  </div>
                </div>
                <GetButton app={app} label="indir" overlay />
              </div>
              <DownloadBar id={app.id} className="mt-2 text-white" />
            </div>
          </div>
        ))}
      </div>

      {data && (
        <section className="mt-8 overflow-hidden rounded-3xl bg-card p-5 shadow-[var(--shadow-card)]">
          <p className="text-[13px] font-semibold uppercase tracking-wide text-muted-foreground">Olmazsa Olmazlar</p>
          <h2 className="text-[28px] font-bold leading-tight">En Çok İndirilenler</h2>
          <div className="mt-1">
            {data.slice(3).map((a) => (
              <AppRow key={a.id} app={a} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
