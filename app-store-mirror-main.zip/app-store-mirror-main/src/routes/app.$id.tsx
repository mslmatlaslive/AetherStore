import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { ChevronLeft, Lock } from "lucide-react";
import { getApp } from "@/lib/store.functions";
import { AppIcon, GetButton, formatCount } from "@/components/store/AppRow";
import { Stars } from "@/components/store/Stars";
import { DownloadBar } from "@/components/store/DownloadProgress";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/app/$id")({
  head: () => ({
    meta: [
      { title: "Uygulama Detayı — Mağaza" },
      { name: "description", content: "Uygulama bilgileri, puanlar, ekran görüntüleri ve daha fazlası." },
      { property: "og:title", content: "Uygulama Detayı — Mağaza" },
      { property: "og:description", content: "Uygulama bilgileri, puanlar, ekran görüntüleri ve daha fazlası." },
    ],
  }),
  component: AppPage,
});

function fmtSize(b: number) {
  if (!b) return "-";
  const mb = b / 1024 / 1024;
  return mb > 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${mb.toFixed(1)} MB`;
}
const fmtDate = (d?: string) => (d ? new Date(d).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" }) : "-");

function AppPage() {
  const { id } = Route.useParams();
  const router = useRouter();
  const fn = useServerFn(getApp);
  const { user, ready, openAuth } = useAuth();
  const { data: app, isLoading } = useQuery({
    queryKey: ["app", id],
    queryFn: () => fn({ data: { id } }),
    staleTime: 600_000,
    enabled: !!user,
  });
  const [more, setMore] = useState(false);

  // Giriş yoksa içerik gösterilmez; giriş penceresi doğrudan açılır.
  useEffect(() => {
    if (ready && !user) openAuth({ reason: "Bu uygulamayı görmek için Proton Mail hesabınızla oturum açın." });
  }, [ready, user, openAuth]);

  if (!ready) return <p className="pt-24 text-center text-muted-foreground">Yükleniyor…</p>;
  if (!user)
    return (
      <div className="flex flex-col items-center px-8 pt-32 text-center">
        <Lock className="h-10 w-10 text-muted-foreground" />
        <p className="mt-3 text-[17px] font-semibold">Oturum açmanız gerekiyor</p>
        <p className="mt-1 text-[14px] text-muted-foreground">Uygulama içeriğine yalnızca Proton Mail hesabıyla giriş yapanlar erişebilir.</p>
        <button
          onClick={() => openAuth({ reason: "Bu uygulamayı görmek için Proton Mail hesabınızla oturum açın." })}
          className="mt-5 rounded-full bg-primary px-6 py-2 text-[15px] font-bold text-primary-foreground"
        >
          Oturum Aç
        </button>
      </div>
    );

  if (isLoading) return <p className="pt-24 text-center text-muted-foreground">Yükleniyor…</p>;
  if (!app) return <p className="pt-24 text-center text-muted-foreground">Uygulama bulunamadı</p>;

  const stats = [
    { top: `${formatCount(app.ratingCount ?? 0)} DEĞERLENDİRME`, mid: (app.rating ?? 0).toFixed(1), bot: <Stars value={app.rating ?? 0} size={10} /> },
    { top: "İNDİRME", mid: formatCount(app.downloads ?? 0), bot: "Kez" },
    { top: "YAŞ", mid: app.age, bot: "" },
    { top: "GELİŞTİRİCİ", mid: app.developer.split(" ")[0], bot: "" },
    { top: "SÜRÜM", mid: app.version.split(".").slice(0, 2).join("."), bot: "" },
    { top: "BOYUT", mid: fmtSize(app.size).split(" ")[0], bot: fmtSize(app.size).split(" ")[1] ?? "" },
  ];

  return (
    <div className="pb-8">
      <div className="sticky top-0 z-40 flex items-center bg-background/85 px-2 py-2 backdrop-blur-xl">
        <button onClick={() => router.history.back()} className="flex items-center text-[17px] text-primary">
          <ChevronLeft className="h-7 w-7" /> Geri
        </button>
      </div>

      <div className="flex gap-4 px-5 pt-2">
        <AppIcon src={app.icon} size={118} />
        <div className="flex min-w-0 flex-1 flex-col">
          <h1 className="text-[22px] font-semibold leading-tight">{app.name}</h1>
          <p className="truncate text-[15px] text-muted-foreground">{app.developer}</p>
          <div className="mt-auto">
            <DownloadBar id={app.id} className="mb-2" />
            <GetButton app={app} big />
          </div>
        </div>
      </div>

      <div className="mt-5 flex overflow-x-auto border-y border-border px-5 py-3 no-scrollbar">
        {stats.map((s, i) => (
          <div key={i} className={`flex min-w-[110px] flex-col items-center px-2 text-center ${i ? "border-l border-border" : ""}`}>
            <span className="text-[11px] font-medium text-muted-foreground">{s.top}</span>
            <span className="max-w-[100px] truncate text-[20px] font-bold text-muted-foreground">{s.mid}</span>
            <span className="text-[12px] text-muted-foreground">{s.bot}</span>
          </div>
        ))}
      </div>

      {app.releaseNotes && (
        <section className="border-b border-border px-5 py-4">
          <div className="flex justify-between">
            <h2 className="text-[20px] font-bold">Yenilikler</h2>
          </div>
          <div className="flex justify-between text-[14px] text-muted-foreground">
            <span>Sürüm {app.version}</span>
            <span>{fmtDate(app.updated)}</span>
          </div>
          <p className="mt-2 whitespace-pre-line text-[15px]">{app.releaseNotes}</p>
        </section>
      )}

      {app.screenshots.length > 0 && (
        <section className="py-4">
          <h2 className="px-5 text-[20px] font-bold">Önizleme</h2>
          <div className="mt-3 flex gap-3 overflow-x-auto px-5 no-scrollbar snap-x">
            {app.screenshots.map((s) => (
              <img key={s} src={s} alt="" loading="lazy" className="h-[460px] w-auto shrink-0 snap-start rounded-2xl border border-border" />
            ))}
          </div>
        </section>
      )}

      <section className="border-t border-border px-5 py-4">
        <p className={`whitespace-pre-line text-[15px] ${more ? "" : "line-clamp-3"}`}>{app.description}</p>
        {!more && (
          <button onClick={() => setMore(true)} className="text-[15px] text-primary">daha fazla</button>
        )}
      </section>

      <section className="border-t border-border px-5 py-4">
        <h2 className="text-[20px] font-bold">Puanlar ve Yorumlar</h2>
        <div className="mt-2 flex items-end gap-4">
          <span className="text-[60px] font-bold leading-none">{(app.rating ?? 0).toFixed(1)}</span>
          <div className="pb-2 text-[13px] text-muted-foreground">
            <span className="block">5 üzerinden</span>
            {formatCount(app.ratingCount ?? 0)} Değerlendirme
          </div>
        </div>
      </section>

      <section className="border-t border-border px-5 py-4">
        <h2 className="mb-2 text-[20px] font-bold">Bilgiler</h2>
        {[
          ["Sağlayıcı", app.developer],
          ["Boyut", fmtSize(app.size)],
          ["Kategori", app.genre],
          ["Uyumluluk", `Android ${app.minOs}`],
          ["İndirme", formatCount(app.downloads ?? 0)],
          ["Yaş Sınırı", app.age],
          ["Sürüm", app.version],
          ["İlk Yayın", fmtDate(app.released)],
          ["Fiyat", "Ücretsiz"],
        ].map(([k, v]) => (
          <div key={k} className="flex justify-between gap-4 border-b border-border py-3 text-[14px]">
            <span className="text-muted-foreground">{k}</span>
            <span className="text-right">{v}</span>
          </div>
        ))}
      </section>
    </div>
  );
}
