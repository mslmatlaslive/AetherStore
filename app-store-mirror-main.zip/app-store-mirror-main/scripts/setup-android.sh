#!/usr/bin/env bash
# Kullanım: bash scripts/setup-android.sh
set -euo pipefail

npm i @capacitor/core @capacitor/android
npm i -D @capacitor/cli
[ -d android ] || npx cap add android

PKG_DIR=android/app/src/main/java/com/aetheros/store
mkdir -p "$PKG_DIR" android/app/src/main/res/xml
cp android-native/java/ApkInstallerPlugin.java "$PKG_DIR/"
cp android-native/java/MainActivity.java "$PKG_DIR/"
cp android-native/res/xml/file_paths.xml android/app/src/main/res/xml/

MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q REQUEST_INSTALL_PACKAGES "$MANIFEST"; then
  sed -i 's#<application#<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n    <application#' "$MANIFEST"
fi
if ! grep -q "fileprovider" "$MANIFEST"; then
  sed -i 's#</application>#    <provider android:name="androidx.core.content.FileProvider" android:authorities="${applicationId}.fileprovider" android:exported="false" android:grantUriPermissions="true"><meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths" /></provider>\n    </application>#' "$MANIFEST"
fi

npx cap sync android
echo "Tamam. Android Studio'da açmak için: npx cap open android"
